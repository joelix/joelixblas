# joelixblas
This is a simple implementation of some blas routines. It was mainly used for educational purposes for programming courses at the University of Bonn.
